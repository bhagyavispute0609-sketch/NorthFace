# NorthFace Android app shell

This is a Trusted Web Activity (TWA) wrapper for the already-working NorthFace Spotify PWA.

## Before building
1. Open `app/src/main/res/values/strings.xml`.
2. Replace `https://YOUR-NORTHFACE-SITE.netlify.app/` with the exact HTTPS URL of your working NorthFace site.
3. Build the Android app in Android Studio.

## Important Spotify detail
NorthFace should stay a TWA rather than a plain WebView. The Spotify Web Playback SDK is browser-based and supports modern mobile browsers. Keep the hosted NorthFace site as the source of truth for Spotify playback.

## Full-screen TWA verification
For a verified Trusted Web Activity, the website must publish an Android Digital Asset Links file at:
`https://YOUR-NORTHFACE-SITE.netlify.app/.well-known/assetlinks.json`

The exact SHA-256 certificate fingerprint depends on the signing key used to build the APK. After you choose the final signing key, put its fingerprint in `assetlinks.json` alongside package name `com.northface.music`.

If the origin is not verified yet, Android can still open the site through the browser/custom-tab path, but it may show browser UI instead of the seamless full-screen TWA experience.

## Spotify redirect URI
The Spotify redirect URI remains the HTTPS URL used by the web app. The Android wrapper does not replace the web OAuth flow.
