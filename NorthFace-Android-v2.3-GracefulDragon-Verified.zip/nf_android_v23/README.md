# NorthFace Android v2.3

Trusted Web Activity wrapper for https://graceful-dragon-6f9f89.netlify.app/

Important: the manifest intent filter is explicitly verified against the current graceful-dragon host. The Digital Asset Links file on that host must contain the APK signing fingerprint shown by the GitHub Actions build.
