# NorthFace v2.4 Android app

This Android wrapper loads the NorthFace production site:
https://graceful-dragon-6f9f89.netlify.app/

It uses the NorthFace mountain image as the Android launcher icon and keeps the permanent signing setup.

## GitHub Actions secrets required
Create these repository secrets before running the workflow:
- NORTHFACE_KEYSTORE_BASE64
- NORTHFACE_KEYSTORE_PASSWORD
- NORTHFACE_KEY_ALIAS
- NORTHFACE_KEY_PASSWORD

Then open Actions → Build NorthFace APK → Run workflow.
Download the APK from the workflow's Artifacts section.

Do not commit the keystore or passwords to the repository.
