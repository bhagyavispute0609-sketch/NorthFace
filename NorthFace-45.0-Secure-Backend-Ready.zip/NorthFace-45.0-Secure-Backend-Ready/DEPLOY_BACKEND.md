# NorthFace V45 — Secure backend deployment

This release is a single consolidated package. The frontend remains deployable on Netlify; the secure account/licensing API is under `backend/` and is prepared for Render.

## Why this fixes the JSON error

The previous error (`Unexpected token '<'`) happened because Netlify was receiving an HTML page at `/api/auth/register` instead of JSON from a running API. V45 includes a real Node/Express API, PostgreSQL wiring, migrations, and a Render Blueprint.

## Deploy the API

1. Put this whole project in a GitHub repository. Keep `backend/.env` out of Git.
2. In Render, choose **New → Blueprint** and connect the repository. Render supports Blueprints from a root `render.yaml` and can provision the web service plus Postgres database defined there. See the official Render docs: https://render.com/docs/blueprint-spec
3. During the initial Blueprint setup, enter `CORS_ORIGIN` as the exact Netlify origin, e.g. `https://your-site.netlify.app` (no trailing slash), and `ADMIN_BOOTSTRAP_EMAIL` as the email you want to become `SUPER_ADMIN` on its first registration.
4. Deploy the Blueprint. The API will have a public `onrender.com` URL. Render web services must listen on `0.0.0.0`; V45 already does this. See: https://render.com/docs/web-services
5. Open `https://YOUR-API.onrender.com/health`. You want JSON showing `ok: true` and `database: connected`.

## Connect the Netlify frontend

Open `api-config.js` in the frontend and replace `/api` with:

```js
window.NORTHFACE_API_BASE = 'https://YOUR-API.onrender.com/api';
```

Then redeploy the frontend to Netlify.

## Important

- Do not put the PostgreSQL password, admin password, or any secret in the frontend.
- Do not commit `.env`.
- The first registration matching `ADMIN_BOOTSTRAP_EMAIL` receives `SUPER_ADMIN`; choose that email before anyone creates that account.
- Render's current documentation notes that free Postgres databases expire after 30 days, so use a paid/persistent database before real production data or real artists are onboarded. See: https://render.com/docs/your-first-deploy
- This is a production-oriented foundation, not legal/compliance sign-off. Email verification, password reset, MFA/passkeys, KYC/tax, storage/CDN, and payment systems still need to be added before public commercial launch.
