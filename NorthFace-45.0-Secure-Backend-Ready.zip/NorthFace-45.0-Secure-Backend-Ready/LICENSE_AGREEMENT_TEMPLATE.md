# NorthFace Artist / Rights-Holder Music License — Draft Template

**IMPORTANT:** This is a product-development template, not legal advice and not a binding agreement. Have qualified music/IP counsel adapt it for the countries, rights, business model, tax treatment and royalty structure NorthFace will actually use.

## 1. Parties
- **Platform:** NorthFace / legal entity to be inserted.
- **Rights Holder:** the artist, label, publisher or other entity identified in the deal record.

## 2. Grant
Subject to the final negotiated agreement, Rights Holder grants NorthFace the non-exclusive rights expressly listed in the signed agreement, which may include hosting, reproduction as technically necessary, digital transmission, interactive on-demand streaming, public communication, caching/technical copies, search/discovery, playlists and reasonable promotional use.

No right is granted merely because a track was uploaded. Publication occurs only after rights review and approval.

## 3. Territory
The agreement must state the exact territories. Use **Worldwide** only when the Rights Holder actually controls and grants the required rights worldwide.

## 4. Term
The agreement must state an effective date, expiry/renewal terms and any post-expiry takedown window.

## 5. Ownership / warranties
Rights Holder represents that it controls or is authorized to grant the rights stated in the agreement and will disclose co-writers, publishers, labels, distributors, samples, interpolations, exclusivity and other restrictions.

## 6. Composition rights
The parties must identify the musical and literary works embodied in each recording and the relevant writers/publishers/collecting societies. A master license does not automatically clear underlying composition rights.

## 7. Royalties and reporting
The final agreement must define the royalty base, deductions if any, accounting period, statement format, payment timing, audit rights, taxes and payment method.

## 8. Takedown / termination
NorthFace must be able to disable a recording when the license expires, a rights dispute is substantiated, a contractual condition is breached, or a lawful takedown is required. The agreement should define notice and cure periods where appropriate.

## 9. Metadata and attribution
The Rights Holder supplies accurate artist, title, ISRC, writers, publishers, label, copyright and attribution information. Required attribution must be preserved in the product where applicable.

## 10. Compliance
The final agreement should address applicable copyright, privacy, consumer, sanctions, tax, child-safety and platform requirements in the relevant territories.

## 11. Signatures
The production version should use a qualified e-signature workflow and preserve immutable contract versions, signer identity, timestamps and the exact rights schedule accepted by both parties.
