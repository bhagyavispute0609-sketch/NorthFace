let songs=[
["cat1", "25 for 25", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/25-for-25-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat2", "78 Pulse", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/78-PULSE-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat3", "A Track Called Birthday", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/A-track-called-Birthday-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat4", "After the Flu", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/After-the-flu-By-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat5", "All Good Again", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/All-good-again-By-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat6", "All I Did", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/All-I-did-remastered-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat7", "Allura", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Allura-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat8", "Altweibersommer", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Altweibersommer-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat9", "April Showers", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/April-Showers-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat10", "Attention", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Attention-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat11", "Berlin Town", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Berlin-Town-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat12", "Blip Blop Tuesday", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Blip-Blop-Tuesday-By-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat13", "Bosch's Garden", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Boschs-Garden-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat14", "Bossanossa", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Bossanossa-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat15", "Crossed Path", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Crossed-Path-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat16", "Noire", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Noire-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat17", "Outrun Boulevard", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Outrun-Boulevard-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat18", "Press Play on Tape", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/PRESS-PLAY-ON-TAPE-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat19", "Project Nine", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Project-Nine-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat20", "Snabba Ladda", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Snabba-Ladda-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat21", "Stagepop", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Stagepop-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat22", "Stardust", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Stardust-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat23", "Sunny Dream", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Sunny-Dream-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat24", "Suspension", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Suspension-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat25", "There Will Be Stars", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/There-will-be-stars-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat26", "Thinking of Driving", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Thinking-of-driving-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat27", "To the Ocean", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/To-the-ocean.ogg", "CC BY-SA 4.0"],
 ["cat28", "Whispers", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Whispers-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat29", "Winterstorm I", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Winterstorm-I-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat30", "Winterstorm II", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Winterstorm-II-by-Kjartan-Abel-1.ogg", "CC BY-SA 4.0"],
 ["cat31", "You Told Me", "Kjartan Abel", "https://commons.wikimedia.org/wiki/Special:Redirect/file/You-told-me-by-Kjartan-Abel.ogg", "CC BY-SA 4.0"],
 ["cat32", "12 Mornings", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-12mornings.mp3", "CC BY 3.0"],
 ["cat33", "2 Above Zero", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-2abovezero.mp3", "CC BY 3.0"],
 ["cat34", "30 Second Classical", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-30secondclassical.mp3", "CC BY 3.0"],
 ["cat35", "5 Cents Back", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-5centsback.mp3", "CC BY 3.0"],
 ["cat36", "90 Seconds of Funk", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-90secondsoffunk.mp3", "CC BY 3.0"],
 ["cat37", "A Brighter Heart", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-abrighterheart.mp3", "CC BY 3.0"],
 ["cat38", "Acoustic Blues", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-acousticblues.mp3", "CC BY 3.0"],
 ["cat39", "Acoustic Meditation 2", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-acousticmeditation2.mp3", "CC BY 3.0"],
 ["cat40", "Acoustic Rock", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-acousticrock.mp3", "CC BY 3.0"],
 ["cat41", "Acoustic Shuffle", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-acousticshuffle.mp3", "CC BY 3.0"],
 ["cat42", "Act Three", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-actthree.mp3", "CC BY 3.0"],
 ["cat43", "A Darker Heart", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-adarkerheart.mp3", "CC BY 3.0"],
 ["cat44", "Algorithm", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-algorithm.mp3", "CC BY 3.0"],
 ["cat45", "Alien Sunset", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-aliensunset.mp3", "CC BY 3.0"],
 ["cat46", "Alison", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-alison.mp3", "CC BY 3.0"],
 ["cat47", "Before Dawn", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-beforedawn.mp3", "CC BY 3.0"],
 ["cat48", "Beginning", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-beginning.mp3", "CC BY 3.0"],
 ["cat49", "Big Blues", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-bigblues.mp3", "CC BY 3.0"],
 ["cat50", "Big Bluesbed", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-bigbluesbed.mp3", "CC BY 3.0"],
 ["cat51", "Big Car Theft", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-bigcartheft.mp3", "CC BY 3.0"],
 ["cat52", "Big Horns Intro", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-bighornsintro.mp3", "CC BY 3.0"],
 ["cat53", "Big Horns Intro 2", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-bighornsintro2.mp3", "CC BY 3.0"],
 ["cat54", "Big Swing Band", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-bigswingband.mp3", "CC BY 3.0"],
 ["cat55", "Bird in Hand", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-birdinhand.mp3", "CC BY 3.0"],
 ["cat56", "Boogie Woogie Bed", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-boogiewoogiebed.mp3", "CC BY 3.0"],
 ["cat57", "Boom", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-boom.mp3", "CC BY 3.0"],
 ["cat58", "Boots Boots Boots", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-bootsbootsboots.mp3", "CC BY 3.0"],
 ["cat59", "Boxcar Rag", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-boxcarrag.mp3", "CC BY 3.0"],
 ["cat60", "Bride’s Ballad", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-bridesballad.mp3", "CC BY 3.0"],
 ["cat61", "Brooker’s Blues", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-brookersblues.mp3", "CC BY 3.0"],
 ["cat62", "Bustin Loose", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-bustinloose.mp3", "CC BY 3.0"],
 ["cat63", "Down the Way", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-downtheway.mp3", "CC BY 3.0"],
 ["cat64", "Drifting 2", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-drifting2.mp3", "CC BY 3.0"],
 ["cat65", "Ecstasy X", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-ecstasyx.mp3", "CC BY 3.0"],
 ["cat66", "Ectoplasm", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-ectoplasm.mp3", "CC BY 3.0"],
 ["cat67", "Edward", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-edward.mp3", "CC BY 3.0"],
 ["cat68", "Egyptian Crawl", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-egyptiancrawl.mp3", "CC BY 3.0"],
 ["cat69", "Emerald Therapy", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-emeraldtherapy.mp3", "CC BY 3.0"],
 ["cat70", "Emily Walks Away", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-emilywalksaway.mp3", "CC BY 3.0"],
 ["cat71", "Enemy Ships", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-enemyships.mp3", "CC BY 3.0"],
 ["cat72", "Energy Bed 2", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-energybed2.mp3", "CC BY 3.0"],
 ["cat73", "Epic Series", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-epicseries.mp3", "CC BY 3.0"],
 ["cat74", "Epic TV Theme", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-epictvtheme.mp3", "CC BY 3.0"],
 ["cat75", "Essence", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-essence.mp3", "CC BY 3.0"],
 ["cat76", "Essence 2", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-essence2.mp3", "CC BY 3.0"],
 ["cat77", "Event Horizon", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-eventhorizon.mp3", "CC BY 3.0"],
 ["cat78", "Everybody Poops", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-everybodypoops.mp3", "CC BY 3.0"],
 ["cat79", "Fat Caps", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-fatcaps.mp3", "CC BY 3.0"],
 ["cat80", "Feel Good Feel", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-feelgoodfeel.mp3", "CC BY 3.0"],
 ["cat81", "Feel Good Rock", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-feelgoodrock.mp3", "CC BY 3.0"],
 ["cat82", "Feels Good 2B", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-feelsgood2b.mp3", "CC BY 3.0"],
 ["cat83", "Fight Scene", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-fightscene.mp3", "CC BY 3.0"],
 ["cat84", "Folk Bed", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-folkbed.mp3", "CC BY 3.0"],
 ["cat85", "Forest Rhythm", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-forestrhythm.mp3", "CC BY 3.0"],
 ["cat86", "Forever Believe", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-foreverbelieve.mp3", "CC BY 3.0"],
 ["cat87", "Front Porch Sitter", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-frontporchsitter.mp3", "CC BY 3.0"],
 ["cat88", "Fun Busy Intro", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-funbusyintro.mp3", "CC BY 3.0"],
 ["cat89", "Funky Junky", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-funkyjunky.mp3", "CC BY 3.0"],
 ["cat90", "Fur Elise", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-furelise.mp3", "CC BY 3.0"],
 ["cat91", "Get a Move On", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-getamoveon.mp3", "CC BY 3.0"],
 ["cat92", "Glitch", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-glitch.mp3", "CC BY 3.0"],
 ["cat93", "Go Not Gently", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-gonotgently.mp3", "CC BY 3.0"],
 ["cat94", "Go Not Gently Redux", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-gonotgentlyredux.mp3", "CC BY 3.0"],
 ["cat95", "Inner Journey", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-innerjourney.mp3", "CC BY 3.0"],
 ["cat96", "Intense Suspense", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-intensesuspense.mp3", "CC BY 3.0"],
 ["cat97", "In the Field", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-inthefield.mp3", "CC BY 3.0"],
 ["cat98", "Intro 5", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-intro5.mp3", "CC BY 3.0"],
 ["cat99", "Intro Action", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-introaction.mp3", "CC BY 3.0"],
 ["cat100", "I Saw Three Ships", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-isawthreeships.mp3", "CC BY 3.0"],
 ["cat101", "Jenny’s Theme", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-jennystheme.mp3", "CC BY 3.0"],
 ["cat102", "Joy to the World", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-joytotheworld.mp3", "CC BY 3.0"],
 ["cat103", "Jumpin Boogie Woogie", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-jumpinboogiewoogie.mp3", "CC BY 3.0"],
 ["cat104", "Keep It Real", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-keepitreal.mp3", "CC BY 3.0"],
 ["cat105", "Kicked Up Pumps", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-kickeduppumps.mp3", "CC BY 3.0"],
 ["cat106", "Landra’s Dream", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-landrasdream.mp3", "CC BY 3.0"],
 ["cat107", "Latin House Bed", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-latinhousebed.mp3", "CC BY 3.0"],
 ["cat108", "Lazy Day", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-lazyday.mp3", "CC BY 3.0"],
 ["cat109", "Leavin the Lights", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-leavinthelights.mp3", "CC BY 3.0"],
 ["cat110", "Legends of the River", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-legendsoftheriver.mp3", "CC BY 3.0"],
 ["cat111", "Lexicon", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-lexicon.mp3", "CC BY 3.0"],
 ["cat112", "Lightning Bugs", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-lightningbugs.mp3", "CC BY 3.0"],
 ["cat113", "Limosine", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-limosine.mp3", "CC BY 3.0"],
 ["cat114", "Line of Fire", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-lineoffire.mp3", "CC BY 3.0"],
 ["cat115", "Lion’s Heart", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-lionsheart.mp3", "CC BY 3.0"],
 ["cat116", "Long Live Death", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-longlivedeath.mp3", "CC BY 3.0"],
 ["cat117", "Macaroon 5", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-macaroon5.mp3", "CC BY 3.0"],
 ["cat118", "Majestic Piano", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-majesticpiano.mp3", "CC BY 3.0"],
 ["cat119", "Mall Walker", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-mallwalker.mp3", "CC BY 3.0"],
 ["cat120", "Marathon Man", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-marathonman.mp3", "CC BY 3.0"],
 ["cat121", "Marauder", "Audionautix", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Audionautix-com-ccby-marauder.mp3", "CC BY 3.0"],
 ["cat122", "Cylinder 1", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_01_-_Cylinder_One.ogg", "CC BY 3.0"],
 ["cat123", "Cylinder 2", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_02_-_Cylinder_Two.ogg", "CC BY 3.0"],
 ["cat124", "Cylinder 3", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_03_-_Cylinder_Three.ogg", "CC BY 3.0"],
 ["cat125", "Cylinder 4", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_04_-_Cylinder_Four.ogg", "CC BY 3.0"],
 ["cat126", "Cylinder 5", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_05_-_Cylinder_Five.ogg", "CC BY 3.0"],
 ["cat127", "Cylinder 6", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_06_-_Cylinder_Six.ogg", "CC BY 3.0"],
 ["cat128", "Cylinder 7", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_07_-_Cylinder_Seven.ogg", "CC BY 3.0"],
 ["cat129", "Cylinder 8", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_08_-_Cylinder_Eight.ogg", "CC BY 3.0"],
 ["cat130", "Cylinder 9", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_09_-_Cylinder_Nine.ogg", "CC BY 3.0"],
 ["cat131", "Prelude No 1", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_01_-_Prelude_No_1.ogg", "CC BY 3.0"],
 ["cat132", "Prelude No 2", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_02_-_Prelude_No_2.ogg", "CC BY 3.0"],
 ["cat133", "Prelude No 3", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_03_-_Prelude_No_3.ogg", "CC BY 3.0"],
 ["cat134", "Prelude No 4", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_04_-_Prelude_No_4.ogg", "CC BY 3.0"],
 ["cat135", "Prelude No 5", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_05_-_Prelude_No_5.ogg", "CC BY 3.0"],
 ["cat136", "Prelude No 6", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_06_-_Prelude_No_6.ogg", "CC BY 3.0"],
 ["cat137", "Prelude No 7", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_07_-_Prelude_No_7.ogg", "CC BY 3.0"],
 ["cat138", "Prelude No 8", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_08_-_Prelude_No_8.ogg", "CC BY 3.0"],
 ["cat139", "Prelude No 9", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_09_-_Prelude_No_9.ogg", "CC BY 3.0"],
 ["cat140", "Prelude No 10", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_10_-_Prelude_No_10.ogg", "CC BY 3.0"],
 ["cat141", "Prelude No 12", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_12_-_Prelude_No_12.ogg", "CC BY 3.0"],
 ["cat142", "Prelude No 13", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_13_-_Prelude_No_13.ogg", "CC BY 3.0"],
 ["cat143", "Prelude No 14", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_14_-_Prelude_No_14.ogg", "CC BY 3.0"],
 ["cat144", "Prelude No 15", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_15_-_Prelude_No_15.ogg", "CC BY 3.0"],
 ["cat145", "Prelude No 16", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_16_-_Prelude_No_16.ogg", "CC BY 3.0"],
 ["cat146", "Prelude No 17", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_17_-_Prelude_No_17.ogg", "CC BY 3.0"],
 ["cat147", "Prelude No 18", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_18_-_Prelude_No_18.ogg", "CC BY 3.0"],
 ["cat148", "Prelude No 19", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_19_-_Prelude_No_19.ogg", "CC BY 3.0"],
 ["cat149", "Prelude No 20", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_20_-_Prelude_No_20.ogg", "CC BY 3.0"],
 ["cat150", "Prelude No 21", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_21_-_Prelude_No_21.ogg", "CC BY 3.0"],
 ["cat151", "Prelude No 22", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_22_-_Prelude_No_22.ogg", "CC BY 3.0"],
 ["cat152", "Prelude No 23", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_23_-_Prelude_No_23.ogg", "CC BY 3.0"],
 ["cat153", "Androids Always Escape", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_01_-_Androids_Always_Escape.ogg", "CC BY 3.0"],
 ["cat154", "The Sun Is Scheduled to Come Out Tomorrow", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_02_-_The_Sun_Is_Scheduled_to_Come_Out_Tomorrow.ogg", "CC BY 3.0"],
 ["cat155", "I Am Running with Temporary Success from a Monstrous Vacuum in Pursuit", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_03_-_I_Am_Running_with_Temporary_Success_from_a_Monstrous_Vacuum_in_Pursuit.ogg", "CC BY 3.0"],
 ["cat156", "I Am Running a Marathon with Thousands of Other Highly Qualified People Who Are All Trying to Defeat Me", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_04_-_I_Am_Running_a_Marathon_with_Thousands_of_Other_Highly_Qualified_People_Who_Are_All_Trying_to_Defeat_Me.ogg", "CC BY 3.0"],
 ["cat157", "I Am Running Down the Long Hallway of Viewmont Elementary", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_05_-_I_Am_Running_Down_the_Long_Hallway_of_Viewmont_Elementary.ogg", "CC BY 3.0"],
 ["cat158", "Laserdisc", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_06_-_Laserdisc.ogg", "CC BY 3.0"],
 ["cat159", "I Am a Man Who Will Fight for Your Honor", "Chris Zabriskie", "https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_07_-_I_Am_a_Man_Who_Will_Fight_for_Your_Honor.ogg", "CC BY 3.0"],
 ["cat160","Cypher","Kjartan Abel","https://commons.wikimedia.org/wiki/Special:Redirect/file/Cypher-by-Kjartan-Abel.ogg","CC BY-SA 4.0"],
 ["cat161","Darkest Thursday","Kjartan Abel","https://commons.wikimedia.org/wiki/Special:Redirect/file/Darkest-Thursday-by-Kjartan-Abel.ogg","CC BY-SA 4.0"],
 ["cat162","In the Desert","Kjartan Abel","https://commons.wikimedia.org/wiki/Special:Redirect/file/In-the-desert-by-Kjartan-Abel.ogg","CC BY-SA 4.0"],
 ["cat163","I Feel It (instrumental)","Sascha Ende","https://commons.wikimedia.org/wiki/Special:Redirect/file/Sascha_Ende_-_I_Feel_It_(instrumental)_(cc-by)_(filmmusic).ogg","CC BY 4.0"],
 ["cat164","The Big Adventure","Sascha Ende","https://commons.wikimedia.org/wiki/Special:Redirect/file/Sascha_Ende_-_The_Big_Adventure_(cc-by)_(filmmusic).ogg","CC BY 4.0"],
 ["cat165","Total Happy Up And Sunny","Sascha Ende","https://commons.wikimedia.org/wiki/Special:Redirect/file/Sascha_Ende_-_Total_Happy_Up_And_Sunny_(cc-by)_(filmmusic.io).ogg","CC BY 4.0"],
 ["cat166","Winter Night","Alexander Nakarada","https://commons.wikimedia.org/wiki/Special:Redirect/file/Alexander_Nakarada_-_Winter_Night_(cc-by)_(filmmusic).ogg","CC BY 4.0"],
 ["cat167","The Return","Alexander Nakarada","https://commons.wikimedia.org/wiki/Special:Redirect/file/Alexander_Nakarada_-_The_Return_(cc-by)_(filmmusic).ogg","CC BY 4.0"],
 ["cat168","Reaching The Sky","Alexander Nakarada","https://commons.wikimedia.org/wiki/Special:Redirect/file/Reaching_The_Sky_by_Alexander_Nakarada.ogg","CC BY 4.0"],
 // Deep catalog expansion — verified Creative Commons recordings mirrored on Wikimedia Commons.
 ["cat169","The Rule","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_The_Rule.ogg","CC BY 3.0"],
 ["cat170","Impact Moderato","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_03_-_Impact_Moderato.ogg","CC BY 3.0"],
 ["cat171","Canon in D Major","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_Canon_in_D_Major.ogg","CC BY 3.0"],
 ["cat172","Sonatina","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_Sonatina.ogg","CC BY 3.0"],
 ["cat173","As I Figure","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_As_I_Figure.ogg","CC BY 3.0"],
 ["cat174","Sneaky Snitch","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_~_Sneaky_Snitch.ogg","CC BY 3.0"],
 ["cat175","Beach Party","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_Beach_Party.ogg","CC BY 3.0"],
 ["cat176","Eastminster","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_Eastminster.ogg","CC BY 3.0"],
 ["cat177","Soporific","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_Soporific.ogg","CC BY 3.0"],
 ["cat178","Smoother Move","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_Smoother_Move.ogg","CC BY 3.0"],
 ["cat179","Dances and Dames","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_Dances_and_Dames.ogg","CC BY 3.0"],
 ["cat180","Ujangong Mix","Kevin MacLeod","https://commons.wikimedia.org/wiki/Special:Redirect/file/Kevin_MacLeod_-_Ujangong_Mix.ogg","CC BY 3.0"],
 ["cat181","Crazy Glue","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_The_Wake_-_04_-_Crazy_Glue.ogg","CC BY 3.0 US"],
 ["cat182","Learn To Fly","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_Here_Today_-_06_-_Learn_To_Fly.ogg","CC BY 3.0 US"],
 ["cat183","On Brevity","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_The_Simple_Life,_Part_2_-_03_-_On_Brevity.ogg","CC BY 3.0 US"],
 ["cat184","I’m Letting Go","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_The_Simple_Life,_Part_1_-_07_-_Im_Letting_Go.ogg","CC BY 3.0 US"],
 ["cat185","Rogue Nation","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_The_Simple_Life,_Part_1_-_10_-_Rogue_Nation.ogg","CC BY 3.0 US"],
 ["cat186","I Will Not Let You Let Me Down","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_The_Wake_-_01_-_I_Will_Not_Let_You_Let_Me_Down.ogg","CC BY 3.0 US"],
 ["cat187","Lafayette","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_The_Wake_-_05_-_Lafayette.ogg","CC BY 3.0 US"],
 ["cat188","Invisible Light","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_The_Wake_-_07_-_Invisible_Light.ogg","CC BY 3.0 US"],
 ["cat189","I Hate You","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_Sunny_Side_of_the_Street_-_04_-_I_Hate_You.ogg","CC BY 3.0 US"],
 ["cat190","Revolution Now","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_The_Simple_Life,_Part_1_-_05_-_Revolution_Now.ogg","CC BY 3.0 US"],
 ["cat191","Josie Has The Upper Hand","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_Not_Quite_Connected_-_10_-_Josie_Has_The_Upper_Hand.ogg","CC BY 3.0 US"],
 ["cat192","Morning Blue","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_The_Simple_Life,_Part_1_-_08_-_Morning_Blue.ogg","CC BY 3.0 US"],
 ["cat193","Violet Wants It Her Way","Josh Woodward","https://commons.wikimedia.org/wiki/Special:Redirect/file/Josh_Woodward_-_Sunny_Side_of_the_Street_-_14_-_Violet_Wants_It_Her_Way.ogg","CC BY 3.0 US"],
 ["cat194","Factory Time","Visager","https://commons.wikimedia.org/wiki/Special:Redirect/file/Visager_-_04_-_Factory_Time.ogg","CC BY 4.0"],
 ["cat195","Haunted Forest","Visager","https://commons.wikimedia.org/wiki/Special:Redirect/file/Visager_-_06_-_Haunted_Forest.ogg","CC BY 4.0"],
 ["cat196","Winter Village","Visager","https://commons.wikimedia.org/wiki/Special:Redirect/file/Visager_-_08_-_Winter_Village.ogg","CC BY 4.0"],
 ["cat197","We Can Do It!","Visager","https://commons.wikimedia.org/wiki/Special:Redirect/file/Visager_-_09_-_We_Can_Do_It.ogg","CC BY 4.0"],
 ["cat198","Final Sacrifice","Visager","https://commons.wikimedia.org/wiki/Special:Redirect/file/Visager_-_14_-_Final_Sacrifice.ogg","CC BY 4.0"],
 ["cat199","Royal Entrance Loop","Visager","https://commons.wikimedia.org/wiki/Special:Redirect/file/Visager_-_18_-_Royal_Entrance_Loop.ogg","CC BY 4.0"],
 ["cat200","Battle Loop","Visager","https://commons.wikimedia.org/wiki/Special:Redirect/file/Visager_-_22_-_Battle_Loop.ogg","CC BY 4.0"],
 ["cat201","Haunted Forest Loop","Visager","https://commons.wikimedia.org/wiki/Special:Redirect/file/Visager_-_23_-_Haunted_Forest_Loop.ogg","CC BY 4.0"],
 ["cat202","Perhaps It Was Not Properly Manufactured","Chris Zabriskie","https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_Perhaps_It_Was_Not_Properly_Manufactured.ogg","CC BY 3.0"],
 ["cat203","Cylinder Eight","Chris Zabriskie","https://commons.wikimedia.org/wiki/Special:Redirect/file/Chris_Zabriskie_-_08_-_Cylinder_Eight.ogg","CC BY 4.0"],
].map(([id,title,artist,src,license])=>({id,title,artist,src,license}));

(() => {
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const audio=$('#audio');
let custom=[]; let liked=JSON.parse(localStorage.nfLiked||'[]'); let recent=JSON.parse(localStorage.nfRecent||'[]');
let audiusSongs=[]; let audiusLoading=false; let audiusSearchTimer=null; let idx=-1; let shuffle=false; let repeat=false;
const nfSettings={quality:localStorage.nfQuality||'standard',crossfade:Number(localStorage.nfCrossfade||0),autoplay:localStorage.nfAutoplay!=='false',shuffle:localStorage.nfShuffle==='true',repeat:localStorage.nfRepeat==='true',personalized:localStorage.nfPersonalized!=='false',activity:localStorage.nfActivity!=='false',recommendations:localStorage.nfRecommendations!=='false'};
const AUDIUS_BASE='https://discoveryprovider.audius.co/v1', AUDIUS_APP='NorthFace';
function normalizeSong(s){
 if(Array.isArray(s)) return {id:s[0]||'song',title:s[1]||'Untitled',artist:s[2]||'Unknown artist',src:s[3]||'',license:s[4]||'NorthFace',source:'NorthFace',artwork:s[5]||''};
 return {id:s?.id||'song',title:s?.title||'Untitled',artist:s?.artist||s?.user?.name||'Unknown artist',src:s?.src||'',license:s?.license||'NorthFace',source:s?.source||'NorthFace',artwork:s?.artwork||s?.cover||'',sourceUrl:s?.sourceUrl||''};
}
function allSongs(){return [...songs,...audiusSongs,...custom].map(normalizeSong).filter(s=>s.id&&s.src)}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function hash(s){let h=0;for(const c of String(s))h=((h<<5)-h)+c.charCodeAt(0)|0;return Math.abs(h)}
function artwork(s){if(s.artwork)return s.artwork;const n=hash(s.id)%6;const labels=['NORTHFACE','AFTER DARK','DISCOVERY','WORLDWIDE','MIDNIGHT','NEW SOUND'];const label=labels[n];const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 700"><rect width="1200" height="700" fill="rgb(${18+n*5},${18+n*5},${18+n*5})"/><circle cx="950" cy="90" r="280" fill="white" opacity=".035"/><circle cx="180" cy="650" r="340" fill="white" opacity=".025"/><text x="70" y="570" font-family="Arial" font-size="54" font-weight="800" fill="white" opacity=".9">${label}</text><text x="72" y="620" font-family="Arial" font-size="18" letter-spacing="7" fill="white" opacity=".35">NORTHFACE</text></svg>`;return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`}
function artStyle(s){return `background-image:url('${String(artwork(s)).replace(/'/g,'%27')}')`}
function card(s){s=normalizeSong(s);return `<article class="music-card"><button class="music-art" data-play="${esc(s.id)}" style="${artStyle(s)}" aria-label="Play ${esc(s.title)}"><span>▶</span></button><div class="music-meta"><button class="music-title" data-play="${esc(s.id)}">${esc(s.title)}</button><span>${esc(s.artist)}</span></div><button class="icon-action ${liked.includes(s.id)?'liked':''}" data-like="${esc(s.id)}" aria-label="Like">${liked.includes(s.id)?'♥':'♡'}</button></article>`}
function listRow(s){s=normalizeSong(s);return `<article class="list-row"><button class="row-art" data-play="${esc(s.id)}" style="${artStyle(s)}" aria-label="Play ${esc(s.title)}"></button><button class="row-info" data-play="${esc(s.id)}"><b>${esc(s.title)}</b><span>${esc(s.artist)}</span></button><button class="icon-action ${liked.includes(s.id)?'liked':''}" data-like="${esc(s.id)}" aria-label="Like">${liked.includes(s.id)?'♥':'♡'}</button><button class="play-action" data-play="${esc(s.id)}" aria-label="Play">▶</button></article>`}
function toast(msg){const t=$('#toast');if(!t)return;t.textContent=msg;t.classList.add('show');clearTimeout(window.__nfToastTimer);window.__nfToastTimer=setTimeout(()=>t.classList.remove('show'),1800)}
window.__nfToast=toast;
function go(page){$$('.page').forEach(p=>p.classList.toggle('active',p.id===page+'Page'));$$('.nav').forEach(n=>n.classList.toggle('active',n.dataset.page===page));window.scrollTo({top:0,behavior:'auto'});if(page==='home')renderHome();if(page==='search')renderSearch($('#searchInput')?.value||'');if(page==='library')renderLibrary();}
function bindStatic(){
 $$('.nav[data-page]').forEach(n=>n.addEventListener('click',()=>go(n.dataset.page)));
 $('#searchBtn')?.addEventListener('click',()=>go('search'));$('#settingsBtn')?.addEventListener('click',()=>go('settings'));$('#topProfileBtn')?.addEventListener('click',openProfile);$('#profileBtn')?.addEventListener('click',openProfile);
 $('#featuredPlay')?.addEventListener('click',()=>{const s=allSongs()[0];if(s)playById(s.id)});
 $('#refreshCatalogBtn')?.addEventListener('click',async()=>{toast('Refreshing creator music…');await loadAudiusHome(true);toast('Fresh music updated')});
 $('#seeAllCreatorBtn')?.addEventListener('click',()=>go('search'));
 $('#recentBtn')?.addEventListener('click',()=>go('library'));
 $('#changeAvatar')?.addEventListener('click',()=>$('#avatarInput')?.click());
 $('#removeAvatar')?.addEventListener('click',()=>{localStorage.removeItem('nfAvatar');loadProfile();toast('Profile photo removed')});
 $('#avatarInput')?.addEventListener('change',e=>{const f=e.target.files?.[0];if(!f)return;if(!f.type.startsWith('image/'))return toast('Choose an image');if(f.size>4*1024*1024)return toast('Use an image under 4 MB');const r=new FileReader();r.onload=()=>{localStorage.nfAvatar=r.result;loadProfile();toast('Profile photo updated')};r.readAsDataURL(f);e.target.value=''});
 $('#saveProfile')?.addEventListener('click',saveProfile);
 $('#accountSetting')?.addEventListener('click',()=>window.NorthFaceAuth?.openAccount());$('#profileSetting')?.addEventListener('click',()=>{if(window.NorthFaceAuth?.user)openProfile();else window.NorthFaceAuth?.openAccount();});$('#membershipSetting')?.addEventListener('click',()=>go('premium'));$('#artistSetting')?.addEventListener('click',()=>go('artist'));

 $('#closeProfile')?.addEventListener('click',closeModals);
 $('#clearHistory')?.addEventListener('click',()=>{localStorage.removeItem('nfRecent');recent=[];renderHome();loadProfile();toast('Recent history cleared')});$('#aboutBtn')?.addEventListener('click',()=>toast('NorthFace v40 • Black Professional'));$('#closeUploadModal')?.addEventListener('click',closeModals);$('#closeCheckout')?.addEventListener('click',closeModals);$('#confirmPurchase')?.addEventListener('click',()=>toast('Secure billing will open in the Android app'));
 $('#premiumPreviewBtn')?.addEventListener('click',()=>toast('Premium personalization preview unlocked for this build'));$$('.plan-btn').forEach(b=>b.addEventListener('click',()=>{$('#checkoutTitle').textContent=b.dataset.plan||'Premium';$('#checkoutPrice').innerHTML=(b.dataset.plan==='Lite'?'₹49':b.dataset.plan==='Elite'?'₹149':'₹99')+'<span>/month</span>';$('#checkout')?.classList.add('open')}));
 $('#closeSettingsModal')?.addEventListener('click',closeModals);$('#closeTerms')?.addEventListener('click',closeModals);$('#closeMusicCredits')?.addEventListener('click',closeModals);
 $('#termsSetting')?.addEventListener('click',()=>$('#termsModal')?.classList.add('open'));$('#musicCreditsSetting')?.addEventListener('click',()=>$('#musicCreditsModal')?.classList.add('open'));
 $('#audioQualitySetting')?.addEventListener('click',()=>openSettingModal('Audio quality','Choose the playback preference used by NorthFace.',`<div class="choice-list">${[['data','Data saver'],['standard','Standard'],['high','High'],['veryhigh','Very high']].map(([k,l])=>`<label class="choice"><span><b>${l}</b><small>${k==='data'?'Lower data use':k==='veryhigh'?'Best available source quality':'Balanced playback'}</small></span><input type="radio" name="quality" value="${k}" ${nfSettings.quality===k?'checked':''}></label>`).join('')}</div><button class="primary" id="saveQuality">Save</button>`));
 $('#crossfadeSetting')?.addEventListener('click',()=>openSettingModal('Crossfade','Fade between tracks for smoother transitions.',`<label class="range-row"><span><b>Crossfade</b><strong id="crossfadePreview">${nfSettings.crossfade}s</strong></span><input id="crossfadeRange" type="range" min="0" max="12" value="${nfSettings.crossfade}"></label><button class="primary" id="saveCrossfade">Save</button>`));
 $('#playbackSetting')?.addEventListener('click',()=>openSettingModal('Playback','Control how tracks continue.',`<div class="choice-list">${[['prefAutoplay','Autoplay','Continue when a track ends',nfSettings.autoplay],['prefShuffle','Shuffle','Mix the next tracks',nfSettings.shuffle],['prefRepeat','Repeat','Repeat the current track',nfSettings.repeat]].map(([id,l,d,c])=>`<label class="choice"><span><b>${l}</b><small>${d}</small></span><input type="checkbox" id="${id}" ${c?'checked':''}></label>`).join('')}</div><button class="primary" id="savePlayback">Save</button>`));
 $('#privacySetting')?.addEventListener('click',()=>openSettingModal('Privacy & personalization','Control local listening data.',`<div class="choice-list">${[['privacyActivity','Listening activity','Store recent plays',nfSettings.activity],['privacyPersonalized','Personalization','Use listening signals',nfSettings.personalized],['privacyRecommendations','Smart recommendations','Show tailored sections',nfSettings.recommendations]].map(([id,l,d,c])=>`<label class="choice"><span><b>${l}</b><small>${d}</small></span><input type="checkbox" id="${id}" ${c?'checked':''}></label>`).join('')}</div><button class="primary" id="savePrivacy">Save</button><button class="secondary" id="clearPrivateData">Clear local listening data</button>`));
 document.addEventListener('pointerup',e=>{const b=e.target.closest?.('button,a,[role=button]');if(b)setTimeout(()=>b.blur(),0);},{passive:true});document.addEventListener('click',handleClick,{passive:false});document.addEventListener('input',e=>{if(e.target.id==='crossfadeRange')$('#crossfadePreview').textContent=e.target.value+'s'});
 $$('.library-tabs [data-tab]').forEach(b=>b.addEventListener('click',()=>{$$('.library-tabs [data-tab]').forEach(x=>x.classList.toggle('active',x===b));renderLibrary()}));
 $('#searchInput')?.addEventListener('input',e=>{clearTimeout(audiusSearchTimer);renderSearch(e.target.value);if(e.target.value.trim().length>=2)audiusSearchTimer=setTimeout(()=>searchAudius(e.target.value),400)});
 $('#importSetting')?.addEventListener('click',()=>$('#fileInput')?.click());$('#fileInput')?.addEventListener('change',e=>{const files=[...(e.target.files||[])];custom=files.map((f,i)=>({id:'local_'+Date.now()+'_'+i,title:f.name.replace(/\.[^.]+$/,''),artist:'On this device',src:URL.createObjectURL(f),source:'Your music',artwork:''}));renderLibrary();renderHome();toast(files.length+' song'+(files.length===1?'':'s')+' added');e.target.value=''});
}
function handleClick(e){const play=e.target.closest?.('[data-play]');if(play){e.preventDefault();playById(play.dataset.play);return}const like=e.target.closest?.('[data-like]');if(like){e.preventDefault();toggleLike(like.dataset.like);return}const mood=e.target.closest?.('[data-mood]');if(mood){e.preventDefault();const groups={chill:'chill',energy:'energy',discover:'discover',global:'global'};const s=allSongs().find(x=>genreFor(x)===groups[mood.dataset.mood])||allSongs()[0];if(s)playById(s.id);return}}
function genreFor(s){const t=(s.title+' '+s.artist).toLowerCase();if(/jazz|blues|swing|bossa/.test(t))return'chill';if(/rap|hip|beat|cypher|boom|funk|pulse|energy|outrun|factory|battle/.test(t))return'energy';if(/canon|sonatina|prelude|classical/.test(t))return'global';return'discover'}
function renderHome(){const all=allSongs(), local=songs.map(normalizeSong);const featured=all[0];if(featured){$('#featuredTitle').textContent=featured.title;$('#featuredArtist').textContent=featured.artist;const b=$('#featuredBanner');b.style.setProperty('--featured-art',`url("${artwork(featured).replace(/"/g,'%22')}")`)}$('#songRail').innerHTML=(nfSettings.recommendations&&nfSettings.personalized)?local.slice(0,6).map(card).join(''):'';$('#audiusRail').innerHTML=audiusSongs.length?audiusSongs.slice(0,6).map(card).join(''):`<div class="empty"><b>Creator music is loading</b><span>Pull to refresh or check your connection.</span></div>`;const rs=recent.map(id=>all.find(s=>s.id===id)).filter(Boolean).slice(0,6);$('#recentRail').innerHTML=rs.length?rs.map(listRow).join(''):`<div class="empty"><b>Nothing played yet</b><span>Pick a song and your history will appear here.</span></div>`;$$('[data-mood]').forEach(b=>b.disabled=false)}
function renderLibrary(){const tab=$('.library-tabs [data-tab].active')?.dataset.tab||'songs';const base=allSongs();const list=tab==='liked'?base.filter(s=>liked.includes(s.id)):tab==='playlists'?[]:base;$('#libraryContent').innerHTML=tab==='playlists'?`<div class="empty"><b>Playlists</b><span>Playlist creation is coming next.</span></div>`:list.slice(0,50).map(listRow).join('')||`<div class="empty"><b>No songs here</b><span>Start listening to build your library.</span></div>`}
function renderSearch(q=''){const query=q.trim().toLowerCase();const list=query?allSongs().filter(s=>(s.title+' '+s.artist).toLowerCase().includes(query)).slice(0,50):allSongs().slice(0,24);$('#searchResults').innerHTML=list.length?list.map(listRow).join(''):`<div class="empty"><b>No results</b><span>Try a different song or artist.</span></div>`}
async function playById(id){const list=allSongs();idx=list.findIndex(s=>s.id===id);if(idx<0)return;const s=list[idx];audio.src=s.src;audio.load();updatePlayer(s);try{await audio.play()}catch(e){toast('Tap play to start audio')};if(nfSettings.activity){recent=[s.id,...recent.filter(x=>x!==s.id)].slice(0,30);localStorage.nfRecent=JSON.stringify(recent)}renderHome();}
function updatePlayer(s){$('#miniPlayer')?.classList.remove('hidden');$('#miniTitle').textContent=s.title;$('#miniArtist').textContent=s.artist;$('#playerTitle').textContent=s.title;$('#playerArtist').textContent=s.artist;$('#playerArt').style.backgroundImage=`url("${artwork(s).replace(/"/g,'%22')}")`;$('#miniArt').style.backgroundImage=`url("${artwork(s).replace(/"/g,'%22')}")`}
function toggleLike(id){liked=liked.includes(id)?liked.filter(x=>x!==id):[...liked,id];localStorage.nfLiked=JSON.stringify(liked);renderHome();renderLibrary();renderSearch($('#searchInput')?.value||'');toast(liked.includes(id)?'Added to Liked Songs':'Removed from Liked Songs')}
function next(){const list=allSongs();if(!list.length)return;if(nfSettings.repeat&&idx>=0){playById(list[idx].id);return}let ni;if(nfSettings.shuffle)ni=Math.floor(Math.random()*list.length);else ni=(idx+1)%list.length;playById(list[ni].id)}
function prev(){const list=allSongs();if(!list.length)return;playById(list[Math.max(0,idx-1)].id)}
function loadProfile(){const au=window.NorthFaceAuth?.user;const n=au?.display_name||localStorage.nfName||'NorthFace User',u=au?.username||localStorage.nfUsername||'northfaceuser',bio=au?.bio||localStorage.nfBio||'',av=localStorage.nfAvatar||'';$('#brandUsername').textContent=n;$('#profileName').value=n==='NorthFace User'?'':n;$('#profileUsername').value=u;$('#profileBio').value=bio;$('#profileDisplayName').textContent=n;$('#profileHandle').textContent='@'+u;$('#profileStatSongs').textContent=allSongs().length;$('#profileStatLiked').textContent=liked.length;$('#profileStatRecent').textContent=recent.length;for(const el of [$('#profileBtn'),$('#topProfileBtn'),$('#profileBig')])if(el){el.textContent=av?'':n.charAt(0).toUpperCase();el.style.backgroundImage=av?`url("${av.replace(/"/g,'%22')}")`:'';el.classList.toggle('has-image',!!av)}}
function openProfile(){loadProfile();$('#profileModal')?.classList.add('open')}
function closeModals(){$$('.modal.open').forEach(m=>m.classList.remove('open'))}
async function saveProfile(){const n=$('#profileName').value.trim()||'NorthFace User',u=($('#profileUsername').value.trim().toLowerCase().replace(/[^a-z0-9_]/g,'')||'northfaceuser'),bio=$('#profileBio').value.trim();localStorage.nfName=n;localStorage.nfUsername=u;localStorage.nfBio=bio;if(window.NorthFaceAuth?.user){const updated=await window.NorthFaceAuth.syncProfile({display_name:n,username:u,bio});if(!updated)return;}loadProfile();closeModals();toast('Profile updated')}
function syncSettings(){const q={data:'Data saver',standard:'Standard',high:'High',veryhigh:'Very high'};$('#audioQualityValue').textContent=q[nfSettings.quality]||'Standard';$('#crossfadeValue').textContent=nfSettings.crossfade?nfSettings.crossfade+'s':'Off';$('#playbackValue').textContent=nfSettings.autoplay?'Autoplay':'Manual'}
function openSettingModal(title,desc,body){$('#settingsModalTitle').textContent=title;$('#settingsModalDescription').textContent=desc;$('#settingsModalBody').innerHTML=body;$('#settingsModal').classList.add('open')}
function saveDynamicSettings(e){if(e.target.id==='saveQuality'){nfSettings.quality=document.querySelector('input[name="quality"]:checked')?.value||'standard';localStorage.nfQuality=nfSettings.quality;syncSettings();closeModals();toast('Audio quality saved')}if(e.target.id==='saveCrossfade'){nfSettings.crossfade=Number($('#crossfadeRange').value);localStorage.nfCrossfade=nfSettings.crossfade;syncSettings();closeModals();toast('Crossfade saved')}if(e.target.id==='savePlayback'){nfSettings.autoplay=$('#prefAutoplay').checked;nfSettings.shuffle=$('#prefShuffle').checked;nfSettings.repeat=$('#prefRepeat').checked;localStorage.nfAutoplay=nfSettings.autoplay;localStorage.nfShuffle=nfSettings.shuffle;localStorage.nfRepeat=nfSettings.repeat;closeModals();toast('Playback saved')}if(e.target.id==='savePrivacy'){nfSettings.activity=$('#privacyActivity').checked;nfSettings.personalized=$('#privacyPersonalized').checked;nfSettings.recommendations=$('#privacyRecommendations').checked;localStorage.nfActivity=nfSettings.activity;localStorage.nfPersonalized=nfSettings.personalized;localStorage.nfRecommendations=nfSettings.recommendations;renderHome();closeModals();toast('Privacy saved')}if(e.target.id==='clearPrivateData'){localStorage.removeItem('nfRecent');localStorage.removeItem('nfLiked');recent=[];liked=[];renderHome();renderLibrary();loadProfile();toast('Local listening data cleared')}}
document.addEventListener('click',e=>{saveDynamicSettings(e);if(e.target.closest?.('.modal')&&e.target.classList.contains('modal'))e.target.classList.remove('open');});
$('#playBtn')?.addEventListener('click',()=>{if(audio.src)audio.paused?audio.play():audio.pause()});$('#shuffleBtn')?.addEventListener('click',()=>{nfSettings.shuffle=!nfSettings.shuffle;localStorage.nfShuffle=nfSettings.shuffle;$('#shuffleBtn').classList.toggle('active',nfSettings.shuffle);toast(nfSettings.shuffle?'Shuffle on':'Shuffle off')});$('#repeatBtn')?.addEventListener('click',()=>{nfSettings.repeat=!nfSettings.repeat;localStorage.nfRepeat=nfSettings.repeat;$('#repeatBtn').classList.toggle('active',nfSettings.repeat);toast(nfSettings.repeat?'Repeat on':'Repeat off')});$('#miniPlay')?.addEventListener('click',()=>{if(audio.src)audio.paused?audio.play():audio.pause()});$('#nextBtn')?.addEventListener('click',next);$('#miniNext')?.addEventListener('click',next);$('#prevBtn')?.addEventListener('click',prev);$('#miniPrev')?.addEventListener('click',prev);$('#closePlayer')?.addEventListener('click',closeModals);$('#miniArt')?.addEventListener('click',()=>$('#player')?.classList.add('open'));
audio.addEventListener('timeupdate',()=>{if(audio.duration){$('#progress').value=(audio.currentTime/audio.duration)*100;$('#currentTime').textContent=fmt(audio.currentTime);$('#duration').textContent=fmt(audio.duration)}});audio.addEventListener('ended',()=>{if(nfSettings.autoplay)next()});$('#progress')?.addEventListener('input',e=>{if(audio.duration)audio.currentTime=(Number(e.target.value)/100)*audio.duration});
function fmt(n){n=Math.floor(n||0);return Math.floor(n/60)+':'+String(n%60).padStart(2,'0')}
async function fetchAudius(path){const r=await fetch(`${AUDIUS_BASE}${path}${path.includes('?')?'&':'?'}app_name=${encodeURIComponent(AUDIUS_APP)}`);if(!r.ok)throw Error('Audius '+r.status);return (await r.json()).data||[]}
function audiusLicenseAllowed(t){const l=String(t.license||t.licenseType||'').toLowerCase();return !/(by-nc|non.?commercial|nc-nd|nc-sa|nc)/i.test(l)}
function audiusMap(t){return {id:'au_'+t.id,title:t.title||'Untitled',artist:t.user?.name||t.user?.handle||'Creator',src:`${AUDIUS_BASE}/tracks/${encodeURIComponent(t.id)}/stream?app_name=${encodeURIComponent(AUDIUS_APP)}`,license:t.license||'Audius Open Music License',source:'Audius',artwork:t.artwork?._1000x1000||t.artwork?._480x480||''}}
async function loadAudiusHome(force=false){if(audiusLoading&&!force)return;audiusLoading=true;try{const d=await fetchAudius('/tracks/trending?limit=30&time=week');audiusSongs=d.filter(audiusLicenseAllowed).map(audiusMap).filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i).slice(0,20);renderHome()}catch(e){console.warn(e)}finally{audiusLoading=false}}
async function searchAudius(q){try{const d=await fetchAudius('/tracks/search?query='+encodeURIComponent(q.trim())+'&limit=30&sort_method=popular');audiusSongs=[...audiusSongs,...d.filter(audiusLicenseAllowed).map(audiusMap)].filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i).slice(0,120);renderSearch(q)}catch(e){}}
window.NorthFaceUI={go,playById,loadProfile,toast};
function init(){
  const splash=$('#splash');if(splash){splash.style.pointerEvents='none';setTimeout(()=>splash.remove(),450)}
  bindStatic();syncSettings();loadProfile();renderHome();renderLibrary();renderSearch('');loadAudiusHome();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
