# NorthFace Licensing Foundation — V41

This build adds a **rights-first prototype**. It is intentionally local-only because NorthFace accounts/authentication are currently disabled.

## Included
- `licensing.html` — creator rights intake form.
- `admin.html` — local Rights Console for review/clear/block/takedown.
- `RIGHTS_SCHEMA.json` — backend-oriented rights data model.
- `LICENSE_AGREEMENT_TEMPLATE.md` — counsel-review draft structure.

## Workflow
1. Creator submits a rights package.
2. Package enters `PENDING_REVIEW`.
3. Reviewer checks master ownership, composition/literary rights, territory, term, restrictions and supporting documents.
4. Only after approval should a production backend set `CLEARED`.
5. Expiry or dispute moves a release to `EXPIRED`, `BLOCKED` or `TAKEDOWN` as appropriate.
6. Every production change must create an audit event.

## Production architecture
Move this workflow to a server before real artists or commercial catalog are onboarded:
- PostgreSQL: artists, recordings, compositions, rights, contracts, territories, takedowns, audit events.
- Object storage: contracts and proof-of-rights documents.
- Auth/RBAC: artist, reviewer, admin, finance roles.
- Server-side approval: never trust a browser/localStorage status.
- Immutable contract versions and signed acceptance records.
- Royalty ledger separate from subscription billing.
- Automated expiry/takedown jobs.
- Complete play logs for royalty/accounting reports.

## Legal note
Music streaming commonly involves separate rights in the sound recording and the underlying musical/literary works. In India, IPRS states that online streaming/OTT platforms require licensing for its repertoire and distinguishes those underlying works from sound-recording rights. NorthFace must obtain the rights actually required for each catalog item rather than assuming one license clears everything.


## V43 security upgrade

V43 adds server-side accounts and sessions. Rights submissions are tied to the signed-in user. Only `ADMIN` and `SUPER_ADMIN` users can review, clear, block, expire, or take down rights records. Sessions use random opaque tokens stored only as SHA-256 hashes in PostgreSQL and are delivered through an HttpOnly cookie. Passwords use Node.js scrypt hashing.

The static Netlify frontend expects the backend at `/api` by default. If the API lives on another HTTPS origin, change `window.NORTHFACE_API_BASE` in `api-config.js` and configure `CORS_ORIGIN` on the backend.


## V44 account connection
Artist submissions now require an authenticated NorthFace account and are stored against that user in the secure API. Admin review remains server-side and role-protected.
