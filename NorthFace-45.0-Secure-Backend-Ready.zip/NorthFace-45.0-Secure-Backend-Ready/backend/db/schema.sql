create extension if not exists pgcrypto;

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  password_hash text not null,
  display_name text not null,
  username text unique,
  bio text not null default '',
  country text,
  role text not null default 'USER' check(role in ('USER','ARTIST','ADMIN','SUPER_ADMIN')),
  email_verified_at timestamptz,
  disabled_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table users add column if not exists bio text not null default '';

create table if not exists sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create table if not exists artists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references users(id) on delete set null,
  display_name text not null,
  email text unique,
  country text,
  created_at timestamptz not null default now()
);

create table if not exists rights_records (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid references artists(id) on delete set null,
  submitted_by uuid references users(id) on delete set null,
  title text not null,
  isrc text,
  audio_url text,
  master_owner text,
  composition_owner text,
  license_type text not null,
  license_reference text,
  territory text not null default 'Worldwide',
  term text,
  interactive boolean not null default true,
  downloads boolean not null default false,
  attribution_required boolean not null default false,
  rights_notes text,
  status text not null default 'PENDING_REVIEW' check(status in ('PENDING_REVIEW','CLEARED','BLOCKED','TAKEDOWN','EXPIRED')),
  reviewer_id uuid references users(id) on delete set null,
  reviewed_at timestamptz,
  review_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists contracts (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid references artists(id) on delete set null,
  rights_record_id uuid references rights_records(id) on delete set null,
  contract_version integer not null default 1,
  status text not null default 'DRAFT' check(status in ('DRAFT','SENT','SIGNED','VOID','EXPIRED')),
  storage_key text,
  signed_at timestamptz,
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists audit_events (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists sessions_user_idx on sessions(user_id);
create index if not exists sessions_expiry_idx on sessions(expires_at);
create index if not exists rights_status_idx on rights_records(status);
create index if not exists rights_artist_idx on rights_records(artist_id);
create index if not exists rights_submitter_idx on rights_records(submitted_by);
create index if not exists audit_entity_idx on audit_events(entity_type, entity_id);
