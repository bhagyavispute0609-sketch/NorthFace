import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import pg from 'pg';
import crypto from 'node:crypto';

const { Pool } = pg;
const app = express();
const port = Number(process.env.PORT || 8787);
const cookieName = 'nf_session';
const sessionDays = Number(process.env.SESSION_DAYS || 30);
const pool = process.env.DATABASE_URL ? new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL.includes('localhost') ? false : { rejectUnauthorized: false }
}) : null;

const corsOrigin = process.env.CORS_ORIGIN || null;
app.use(cors({ origin: corsOrigin || false, credentials: true }));

// Small in-memory rate limiter for auth endpoints. Use a distributed limiter at scale.
const buckets = new Map();
function rateLimit(limit, windowMs){ return (req,res,next)=>{ const key=(req.ip||'unknown')+'|'+req.path; const now=Date.now(); const b=buckets.get(key); if(!b || now-b.start>=windowMs){ buckets.set(key,{start:now,count:1}); return next(); } if(b.count>=limit) return res.status(429).json({error:'Too many requests. Please try again later.'}); b.count++; next(); }; }
app.use((req,res,next)=>{ const origin=req.headers.origin; if(origin && corsOrigin && origin!==corsOrigin) return res.status(403).json({error:'Origin not allowed.'}); next(); });
app.use(express.json({ limit: '2mb' }));
app.set('trust proxy', 1);

const requireDb = (req, res, next) => {
  if (!pool) return res.status(503).json({ error: 'Database not configured.' });
  next();
};

const normalizeEmail = v => String(v || '').trim().toLowerCase();
const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
const makeToken = () => crypto.randomBytes(48).toString('base64url');
const hashPassword = async password => {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = await new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, { N: 16384, r: 8, p: 1 }, (e, d) => e ? reject(e) : resolve(d)));
  return `scrypt$${salt}$${derived.toString('hex')}`;
};
const verifyPassword = async (password, stored) => {
  const [, salt, expected] = String(stored).split('$');
  if (!salt || !expected) return false;
  const actual = await new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, { N: 16384, r: 8, p: 1 }, (e, d) => e ? reject(e) : resolve(d)));
  const a = Buffer.from(expected, 'hex'); const b = Buffer.from(actual);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};
const parseCookies = req => Object.fromEntries(String(req.headers.cookie || '').split(';').map(x => x.trim()).filter(Boolean).map(x => { const i=x.indexOf('='); return [i<0?x:x.slice(0,i), i<0?'':decodeURIComponent(x.slice(i+1))]; }));
const setSessionCookie = (res, token, maxAge) => res.setHeader('Set-Cookie', `${cookieName}=${encodeURIComponent(token)}; Max-Age=${maxAge}; Path=/; HttpOnly; SameSite=${cookieSameSite}${process.env.COOKIE_SECURE !== 'false' ? '; Secure' : ''}`);
const cookieSameSite = process.env.COOKIE_SAMESITE || 'None';
const clearSessionCookie = res => res.setHeader('Set-Cookie', `${cookieName}=; Max-Age=0; Path=/; HttpOnly; SameSite=${cookieSameSite}${process.env.COOKIE_SECURE !== 'false' ? '; Secure' : ''}`);

async function getUser(req) {
  if (!pool) return null;
  const token = parseCookies(req)[cookieName];
  if (!token) return null;
  const result = await pool.query(`select u.id,u.email,u.display_name,u.username,u.bio,u.country,u.role,u.email_verified_at,u.disabled_at from sessions s join users u on u.id=s.user_id where s.token_hash=$1 and s.expires_at>now()`, [sha256(token)]);
  const user = result.rows[0];
  if (!user || user.disabled_at) return null;
  await pool.query(`update sessions set last_seen_at=now() where token_hash=$1`, [sha256(token)]);
  return user;
}

const requireAuth = async (req, res, next) => {
  try { req.user = await getUser(req); if (!req.user) return res.status(401).json({ error: 'Authentication required' }); next(); }
  catch { res.status(500).json({ error: 'Authentication service error' }); }
};
const requireAdmin = async (req, res, next) => {
  await requireAuth(req, res, () => {
    if (!['ADMIN','SUPER_ADMIN'].includes(req.user.role)) return res.status(403).json({ error: 'Admin access required' });
    next();
  });
};

app.get('/health', async (req, res) => {
  if (!pool) return res.json({ ok: true, database: 'not_configured' });
  try { await pool.query('select 1'); res.json({ ok: true, database: 'connected' }); }
  catch { res.status(503).json({ ok: false, database: 'error' }); }
});

app.post('/api/auth/register', requireDb, rateLimit(8, 15*60*1000), async (req, res) => {
  const email = normalizeEmail(req.body?.email);
  const password = String(req.body?.password || '');
  const displayName = String(req.body?.display_name || '').trim().slice(0, 64);
  const username = String(req.body?.username || '').trim().toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 32) || null;
  const country = String(req.body?.country || '').trim().slice(0, 64) || null;
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email.' });
  if (password.length < 10) return res.status(400).json({ error: 'Password must be at least 10 characters.' });
  if (!displayName) return res.status(400).json({ error: 'Display name is required.' });
  try {
    const existing = await pool.query('select id from users where email=$1', [email]);
    if (existing.rowCount) return res.status(409).json({ error: 'An account with that email already exists.' });
    const passwordHash = await hashPassword(password);
    const role = process.env.ADMIN_BOOTSTRAP_EMAIL && email === normalizeEmail(process.env.ADMIN_BOOTSTRAP_EMAIL) ? 'SUPER_ADMIN' : 'USER';
    const created = await pool.query(`insert into users(email,password_hash,display_name,username,country,role) values($1,$2,$3,$4,$5,$6) returning id,email,display_name,username,bio,country,role`, [email,passwordHash,displayName,username,country,role]);
    await pool.query(`insert into audit_events(actor_id,action,entity_type,entity_id,metadata) values($1,'REGISTER','user',$1,$2)`, [created.rows[0].id, JSON.stringify({ role })]);
    res.status(201).json({ user: created.rows[0] });
  } catch (e) { res.status(500).json({ error: 'Could not create account.' }); }
});

app.post('/api/auth/login', requireDb, rateLimit(12, 15*60*1000), async (req, res) => {
  const email = normalizeEmail(req.body?.email); const password = String(req.body?.password || '');
  try {
    const result = await pool.query('select * from users where email=$1', [email]);
    const user = result.rows[0];
    if (!user || user.disabled_at || !(await verifyPassword(password, user.password_hash))) return res.status(401).json({ error: 'Incorrect email or password.' });
    const token = makeToken(); const expires = new Date(Date.now() + sessionDays*86400000);
    await pool.query(`insert into sessions(user_id,token_hash,expires_at) values($1,$2,$3)`, [user.id,sha256(token),expires]);
    await pool.query(`insert into audit_events(actor_id,action,entity_type,entity_id,metadata) values($1,'LOGIN','user',$1,'{}')`, [user.id]);
    setSessionCookie(res, token, sessionDays*86400);
    res.json({ user: { id:user.id,email:user.email,display_name:user.display_name,username:user.username,bio:user.bio,country:user.country,role:user.role,email_verified_at:user.email_verified_at } });
  } catch { res.status(500).json({ error: 'Could not sign in.' }); }
});

app.post('/api/auth/logout', requireDb, async (req, res) => {
  const token = parseCookies(req)[cookieName];
  if (token) await pool.query('delete from sessions where token_hash=$1', [sha256(token)]);
  clearSessionCookie(res); res.json({ ok:true });
});
app.get('/api/auth/me', requireDb, async (req, res) => {
  try { const user = await getUser(req); if (!user) return res.status(401).json({ error:'Not signed in' }); res.json({ user }); }
  catch { res.status(500).json({ error:'Could not load account.' }); }
});

app.patch('/api/auth/profile', requireDb, requireAuth, async (req,res)=>{
  const displayName=String(req.body?.display_name||'').trim().slice(0,64);
  const username=String(req.body?.username||'').trim().toLowerCase().replace(/[^a-z0-9_]/g,'').slice(0,32);
  const bio=String(req.body?.bio||'').trim().slice(0,160);
  if(!displayName) return res.status(400).json({error:'Display name is required.'});
  if(username.length<3) return res.status(400).json({error:'Username must be at least 3 characters.'});
  try {
    const updated=await pool.query(`update users set display_name=$1,username=$2,bio=$3,updated_at=now() where id=$4 returning id,email,display_name,username,country,role,email_verified_at`,[displayName,username,bio,req.user.id]);
    if(!updated.rowCount) return res.status(404).json({error:'Account not found.'});
    await pool.query(`insert into audit_events(actor_id,action,entity_type,entity_id,metadata) values($1,'UPDATE_PROFILE','user',$1,$2)`,[req.user.id,JSON.stringify({fields:['display_name','username']})]);
    res.json({user:updated.rows[0]});
  } catch(e) {
    if(e?.code==='23505') return res.status(409).json({error:'That username is already taken.'});
    res.status(500).json({error:'Could not update profile.'});
  }
});

app.get('/api/rights', requireDb, requireAuth, async (req, res) => {
  const { status, q } = req.query; const values=[]; const where=[];
  if (status) { values.push(status); where.push(`r.status=$${values.length}`); }
  if (q) { values.push(`%${q}%`); where.push(`(r.title ilike $${values.length} or a.display_name ilike $${values.length})`); }
  if (!['ADMIN','SUPER_ADMIN'].includes(req.user.role)) { values.push(req.user.id); where.push(`r.submitted_by=$${values.length}`); }
  const sql=`select r.*,a.display_name artist_name from rights_records r left join artists a on a.id=r.artist_id ${where.length?'where '+where.join(' and '):''} order by r.created_at desc limit 200`;
  try { res.json((await pool.query(sql,values)).rows); } catch { res.status(500).json({error:'Failed to load rights records'}); }
});

app.post('/api/rights', requireDb, requireAuth, async (req, res) => {
  const b=req.body||{};
  if (!b.title || !b.license_type) return res.status(400).json({error:'title and license_type are required'});
  const client=await pool.connect();
  try {
    await client.query('begin');
    const artist=await client.query(`insert into artists(user_id,display_name,email,country) values($1,$2,$3,$4) on conflict(user_id) do update set display_name=excluded.display_name,email=excluded.email,country=excluded.country returning id`, [req.user.id,b.artist_name||req.user.display_name,req.user.email,b.country||req.user.country||null]);
    const record=await client.query(`insert into rights_records(artist_id,submitted_by,title,isrc,audio_url,master_owner,composition_owner,license_type,license_reference,territory,term,interactive,downloads,attribution_required,rights_notes) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) returning *`, [artist.rows[0].id,req.user.id,b.title,b.isrc||null,b.audio_url||null,b.master_owner||null,b.composition_owner||null,b.license_type,b.license_reference||null,b.territory||'Worldwide',b.term||null,b.interactive!==false,b.downloads===true,b.attribution_required===true,b.rights_notes||null]);
    await client.query(`insert into audit_events(actor_id,action,entity_type,entity_id,metadata) values($1,'CREATE_RIGHTS_RECORD','rights_record',$2,$3)`, [req.user.id,record.rows[0].id,JSON.stringify({source:'api'})]);
    await client.query('commit'); res.status(201).json(record.rows[0]);
  } catch { await client.query('rollback'); res.status(500).json({error:'Failed to create rights record'}); } finally { client.release(); }
});

app.post('/api/rights/:id/review', requireDb, requireAdmin, async (req, res) => {
  const allowed=new Set(['CLEARED','BLOCKED','TAKEDOWN','EXPIRED','PENDING_REVIEW']); const {status,reason}=req.body||{};
  if (!allowed.has(status)) return res.status(400).json({error:'Invalid status'});
  const client=await pool.connect();
  try { await client.query('begin'); const updated=await client.query(`update rights_records set status=$1,reviewer_id=$2,reviewed_at=now(),review_reason=$3,updated_at=now() where id=$4 returning *`,[status,req.user.id,reason||null,req.params.id]); if(!updated.rowCount){await client.query('rollback');return res.status(404).json({error:'Rights record not found'});} await client.query(`insert into audit_events(actor_id,action,entity_type,entity_id,metadata) values($1,$2,'rights_record',$3,$4)`,[req.user.id,`REVIEW_${status}`,req.params.id,JSON.stringify({reason:reason||null})]); await client.query('commit'); res.json(updated.rows[0]); }
  catch { await client.query('rollback'); res.status(500).json({error:'Failed to review rights record'}); } finally { client.release(); }
});

app.get('/api/admin/audit', requireDb, requireAdmin, async (req,res)=>{ try { res.json((await pool.query(`select ae.*,u.email actor_email from audit_events ae left join users u on u.id=ae.actor_id order by ae.created_at desc limit 500`)).rows); } catch { res.status(500).json({error:'Failed to load audit log'}); } });

app.listen(port,'0.0.0.0',()=>console.log(`NorthFace licensing API listening on :${port}`));
