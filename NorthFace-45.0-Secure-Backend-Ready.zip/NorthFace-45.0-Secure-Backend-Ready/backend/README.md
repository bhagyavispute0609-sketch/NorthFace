# NorthFace V45 Secure Licensing Backend

Node 20 + Express + PostgreSQL. This is the server-side layer for accounts, roles, sessions, rights submissions, admin review, and audit events.

## Setup
1. Create a PostgreSQL database.
2. Run `db/schema.sql` against it.
3. Copy `.env.example` to `.env` and fill in `DATABASE_URL`, `CORS_ORIGIN`, and `ADMIN_BOOTSTRAP_EMAIL`.
4. Run `npm install` then `npm start`.
5. Keep `.env` and all secrets out of Git and out of the frontend ZIP.

## Roles
- USER: normal account
- ARTIST: future creator-specific account role
- ADMIN: rights reviewer
- SUPER_ADMIN: top-level admin

The bootstrap email is only used when registering the first matching account. Do not expose it as a frontend secret.

## Production requirements still ahead
- Email verification / verified-domain workflow
- Password reset through a transactional email provider
- MFA/passkeys for admins
- Object storage for contracts/audio, with signed URLs
- Rate limiting / bot protection
- CSRF strategy if frontend and API are split across sites
- KYC/tax/payout integrations
- Legal review of final contracts and licensing terms

## V45 deployment

This backend includes an idempotent startup migration (`src/migrate.js`), explicit `0.0.0.0` binding for hosted environments, and Render Blueprint support in the repository root.
