// NorthFace API endpoint.
// For Netlify + Render, replace the placeholder with your deployed Render API URL.
// Example: window.NORTHFACE_API_BASE = 'https://northface-api.onrender.com/api';
window.NORTHFACE_API_BASE = window.NORTHFACE_API_BASE || '/api';
