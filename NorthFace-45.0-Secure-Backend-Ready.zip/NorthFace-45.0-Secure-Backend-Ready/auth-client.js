/* NorthFace account client — V44. Uses HttpOnly server sessions. */
(() => {
  const API = window.NORTHFACE_API_BASE || '/api';
  const $ = id => document.getElementById(id);
  window.NorthFaceAuth = { user: null, ready: false };

  async function request(path, options={}) {
    const res = await fetch(`${API}${path}`, { credentials:'include', ...options, headers:{'Content-Type':'application/json', ...(options.headers||{})} });
    let data={}; try { data=await res.json(); } catch {}
    if(!res.ok) throw new Error(data.error || 'Account request failed.');
    return data;
  }
  function setAccountUI(user) {
    const signed = !!user;
    const label = $('accountSettingLabel');
    const sub = $('accountSettingSub');
    const val = $('accountSettingValue');
    if(label) label.textContent = signed ? (user.display_name || 'NorthFace account') : 'Sign in or create account';
    if(sub) sub.textContent = signed ? `@${user.username || 'northfaceuser'} • ${user.role || 'USER'}` : 'Sync profile, rights and membership';
    if(val) val.textContent = signed ? 'Signed in' : 'Sign in';
    const brand = $('brandUsername');
    if(brand && signed) brand.textContent = user.display_name || 'NorthFace User';
  }
  async function load() {
    try { const d=await request('/auth/me'); window.NorthFaceAuth.user=d.user; setAccountUI(d.user); }
    catch { window.NorthFaceAuth.user=null; setAccountUI(null); }
    finally { window.NorthFaceAuth.ready=true; }
  }
  function openAccount() {
    if(window.NorthFaceAuth.user) {
      if(window.NorthFaceUI?.loadProfile) window.NorthFaceUI.loadProfile();
      document.getElementById('profileModal')?.classList.add('open');
    } else location.href='auth.html?next=index.html';
  }
  async function syncProfile(payload) {
    if(!window.NorthFaceAuth.user) return null;
    try {
      const d=await request('/auth/profile',{method:'PATCH',body:JSON.stringify(payload)});
      window.NorthFaceAuth.user=d.user; setAccountUI(d.user); return d.user;
    } catch(e) { if(window.NorthFaceUI?.toast) window.NorthFaceUI.toast(e.message); return null; }
  }
  async function logout() {
    try { await request('/auth/logout',{method:'POST',body:'{}'}); } finally { window.NorthFaceAuth.user=null; setAccountUI(null); location.href='index.html'; }
  }
  window.NorthFaceAuth.openAccount=openAccount;
  window.NorthFaceAuth.syncProfile=syncProfile;
  window.NorthFaceAuth.logout=logout;
  window.addEventListener('DOMContentLoaded',()=>load());
})();
