# NorthFace V44 — Secure accounts setup

This release connects the NorthFace frontend to the V43 server-side account/licensing API.

## 1. Database
Run `backend/db/schema.sql` against PostgreSQL.

## 2. Backend
Inside `backend/`:

```bash
npm install
npm start
```

Create `.env` from `.env.example` and set:
- `DATABASE_URL`
- `CORS_ORIGIN` to the exact HTTPS Netlify origin
- `ADMIN_BOOTSTRAP_EMAIL` if you want the first matching account to receive `SUPER_ADMIN`
- `COOKIE_SECURE=true` in production

## 3. Frontend
Edit `api-config.js` so `window.NORTHFACE_API_BASE` points to the deployed HTTPS API, for example:

```js
window.NORTHFACE_API_BASE = 'https://api.example.com/api';
```

Do not put database passwords or other secrets in the frontend.

## 4. Security notes
- Passwords are hashed with Node `scrypt` and are never stored in plaintext.
- Sessions use random opaque tokens stored only as SHA-256 hashes in PostgreSQL and sent to the browser with HttpOnly cookies.
- Admin rights review is server-side and role checked.
- Auth endpoints have a basic in-memory rate limiter; production should use a shared/distributed limiter.
- Email verification is intentionally not faked. Connect a transactional mail provider before treating accounts as verified.
