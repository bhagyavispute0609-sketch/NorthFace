# NorthFace TWA / Android Browser Helper
# Keep TWA entry points and metadata-driven classes.
-keep class com.google.androidbrowserhelper.** { *; }
