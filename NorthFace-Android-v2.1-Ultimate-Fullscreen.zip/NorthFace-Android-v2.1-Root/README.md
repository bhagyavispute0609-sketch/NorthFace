# NorthFace Android 2.1 — Fullscreen TWA

This Android app launches the NorthFace web app using Android Browser Helper / Trusted Web Activity.

- Package: `com.northface.music`
- Website: `https://ubiquitous-pegasus-e8d9b0.netlify.app/`
- Target: Android 35 / compile 36
- TWA dependency: Android Browser Helper 2.6.2
- Release build is R8/minify optimized and uses the debug signing key for personal sideload testing.
- Digital Asset Links must be publicly available at `/.well-known/assetlinks.json` with the matching SHA-256 fingerprint.

For a production Play Store build, replace the debug signing configuration with a permanent upload/release key and publish its fingerprint in `assetlinks.json`.
