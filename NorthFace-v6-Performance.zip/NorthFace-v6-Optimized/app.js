const CONFIG={clientId:"5c69274bcd5348a5b546907aeedd906a",redirectUri:window.location.origin+window.location.pathname,scopes:["user-read-private","user-read-email","playlist-read-private","playlist-read-collaborative","user-library-read","user-read-playback-state","user-modify-playback-state","user-read-currently-playing","streaming"].join(" ")};
const $=id=>document.getElementById(id);const fmt=ms=>{const s=Math.floor((ms||0)/1000);return`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`};
function randomString(n=64){const a=new Uint8Array(n);crypto.getRandomValues(a);return[...a].map(x=>"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"[x%62]).join("")}async function sha256(s){return crypto.subtle.digest("SHA-256",new TextEncoder().encode(s))}function b64url(buf){return btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_")}
function setStatus(t){$("statusText").textContent=t}
async function login(){const verifier=randomString();const challenge=b64url(await sha256(verifier));localStorage.setItem("nf_verifier",verifier);const state=randomString(32);localStorage.setItem("nf_state",state);const u=new URL("https://accounts.spotify.com/authorize");u.search=new URLSearchParams({client_id:CONFIG.clientId,response_type:"code",redirect_uri:CONFIG.redirectUri,scope:CONFIG.scopes,code_challenge_method:"S256",code_challenge:challenge,state}).toString();location.href=u}
async function callback(){const p=new URLSearchParams(location.search),code=p.get("code"),state=p.get("state"),err=p.get("error");if(err)throw Error(err);if(!code)return;if(state!==localStorage.getItem("nf_state"))throw Error("Spotify login state mismatch");const body=new URLSearchParams({client_id:CONFIG.clientId,grant_type:"authorization_code",code,redirect_uri:CONFIG.redirectUri,code_verifier:localStorage.getItem("nf_verifier")});const r=await fetch("https://accounts.spotify.com/api/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});const data=await r.json();if(data.error)throw Error(data.error_description||data.error);localStorage.setItem("nf_token",data.access_token);localStorage.setItem("nf_expires",String(Date.now()+data.expires_in*1000));if(data.refresh_token)localStorage.setItem("nf_refresh",data.refresh_token);localStorage.removeItem("nf_state");localStorage.removeItem("nf_verifier");history.replaceState({},document.title,CONFIG.redirectUri)}
async function refreshToken(){const refresh=localStorage.getItem("nf_refresh");if(!refresh)return null;const body=new URLSearchParams({client_id:CONFIG.clientId,grant_type:"refresh_token",refresh_token:refresh});const r=await fetch("https://accounts.spotify.com/api/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});const d=await r.json();if(d.access_token){localStorage.setItem("nf_token",d.access_token);localStorage.setItem("nf_expires",String(Date.now()+d.expires_in*1000));if(d.refresh_token)localStorage.setItem("nf_refresh",d.refresh_token)}return d.access_token}
async function token(){if(Date.now()<Number(localStorage.getItem("nf_expires")||0)-60000)return localStorage.getItem("nf_token");return(await refreshToken())||localStorage.getItem("nf_token")}
async function api(path,opts={}){const t=await token();if(!t)throw Error("Not connected");const r=await fetch("https://api.spotify.com/v1"+path,{...opts,headers:{Authorization:"Bearer "+t,...(opts.headers||{})}});if(r.status===401){const nt=await refreshToken();if(nt)return api(path,opts)}if(!r.ok)throw Error((await r.text()).slice(0,300));return r.status===204?null:r.json()}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function trackHTML(t,i=0){const img=t.album?.images?.[0]?.url;return`<div class="track" data-uri="${esc(t.uri||"")}" data-index="${i}">${img?`<img src="${img}" alt="">`:`<div class="track-art">♪</div>`}<div><b>${esc(t.name)}</b><small>${esc(t.artists?.map(a=>a.name).join(", ")||"Unknown artist")}</small></div><span class="track-time">${fmt(t.duration_ms)}</span></div>`}
function bindTracks(root){root.querySelectorAll(".track").forEach(el=>el.onclick=()=>playUri(el.dataset.uri))}
async function loadLibrary(){setStatus("Climbing into your library…");const me=await api("/me");$("userChip").textContent=me.display_name||"Spotify";$("userChip").classList.remove("hidden");$("connectBtn").classList.add("hidden");$("heroConnect").textContent="Spotify connected ✓";$("library").classList.remove("hidden");const data=await api("/me/playlists?limit=50");$("playlistGrid").innerHTML=data.items.map(p=>`<article class="playlist tilt" data-id="${p.id}">${p.images?.[0]?.url?`<img src="${p.images[0].url}" alt="">`:`<div class="playlist-art">N</div>`}<h3>${esc(p.name)}</h3><p>${p.items?.total??0} tracks</p></article>`).join("");document.querySelectorAll(".playlist").forEach(x=>{x.onclick=()=>openPlaylist(x.dataset.id);addTilt(x)});setStatus(`${data.items.length} playlists at base camp`);initPlayer()}
async function openPlaylist(id){
 setStatus("Opening playlist…");
 const [meta,p]=await Promise.all([api(`/playlists/${id}?fields=name,images,description`),api(`/playlists/${id}/items?limit=50&fields=items(item(name,uri,duration_ms,artists(name),album(name,images)))`)]);
 const items=(p.items||[]).filter(x=>x.item);
 $("playlistGrid").classList.add("hidden");$("playlistView").classList.remove("hidden");
 $("playlistHero").innerHTML=`<div class="playlist-banner">${meta.images?.[0]?.url?`<img src="${meta.images[0].url}" alt="">`:`<div class="playlist-art">N</div>`}<div><div class="eyebrow">SPOTIFY PLAYLIST</div><h2>${esc(meta.name)}</h2><p>${esc(meta.description||`${items.length} tracks`)}</p></div></div>`;
 $("playlistTracks").innerHTML=items.map((x,i)=>trackHTML(x.item,i)).join("");
 bindTracks($("playlistTracks"));setStatus(`${items.length} tracks ready`);window.scrollTo({top:document.querySelector(".library").offsetTop-20,behavior:"smooth"});
}
async function playUri(uri){
 if(!uri)return;
 try{
  if(!player){setStatus("Waking NorthFace player…");await initPlayer(true)}
  if(!player)throw Error("player_unavailable");
  if(player.activateElement) await player.activateElement();
  const device=localStorage.getItem("nf_device");
  if(!device)throw Error("player_not_ready");
  await api("/me/player",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({device_ids:[device],play:false})});
  await api("/me/player/play?device_id="+encodeURIComponent(device),{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({uris:[uri]})});
  setStatus("Playing · NorthFace is alive");pulseUI();
 }catch(e){
  console.error(e);
  const m=String(e.message||e);
  if(m.includes("Premium"))setStatus("Spotify Premium is required for web playback");
  else if(m.includes("player_not_ready"))setStatus("Player is not ready yet · tap the song again");
  else setStatus("Spotify playback failed · tap the song again");
 }
}
let player=null,playerStarting=false;
window.onSpotifyWebPlaybackSDKReady=()=>initPlayer();
async function initPlayer(userGesture=false){
 if(player)return true;
 if(playerStarting)return false;
 const t=await token();
 if(!t||!window.Spotify)return false;
 playerStarting=true;
 try{
  player=new Spotify.Player({name:"NorthFace · Everest",volume:.72,getOAuthToken:async cb=>cb(await token()),enableMediaSession:true});
  player.addListener("ready",({device_id})=>{localStorage.setItem("nf_device",device_id);setStatus("NorthFace player ready · choose a song")});
  player.addListener("not_ready",({device_id})=>{if(localStorage.getItem("nf_device")===device_id)localStorage.removeItem("nf_device");setStatus("NorthFace player went offline")});
  player.addListener("player_state_changed",s=>{if(!s)return;const t=s.track_window.current_track;setTrack(t);$("play").textContent=s.paused?"▶":"Ⅱ";$("progress").value=s.duration?s.position/s.duration*100:0;$("time").textContent=fmt(s.position);$("duration").textContent=fmt(s.duration);$("lyricsTrack").textContent=t.name;$("lyricsArtist").textContent=t.artists?.map(a=>a.name).join(", ")||"";const img=t.album?.images?.[0]?.url;if(img){$("miniCover").style.backgroundImage=`url('${img}')`;$("miniCover").textContent=""}pulseUI()});
  player.addListener("autoplay_failed",()=>setStatus("Tap play again to start audio on this phone"));
  player.addListener("initialization_error",e=>setStatus("This browser cannot start Spotify playback"));
  player.addListener("authentication_error",e=>{console.warn(e.message);setStatus("Spotify player authentication failed · reconnect Spotify")});
  player.addListener("account_error",e=>{console.warn(e.message);setStatus("Spotify Premium is required for NorthFace playback")});
  player.addListener("playback_error",e=>{console.warn(e.message);setStatus("Spotify could not play this track")});
  const ok=await player.connect();
  if(!ok)throw Error("connect_failed");
  if(userGesture&&player.activateElement)await player.activateElement();
  return true;
 }catch(e){console.error(e);player=null;setStatus("NorthFace player could not connect to Spotify");return false}
 finally{playerStarting=false}
}
function setTrack(t){$("trackName").textContent=t?.name||"Nothing playing";$("artistName").textContent=t?.artists?.map(a=>a.name).join(", ")||"Connect Spotify to begin";const url=t?.album?.images?.[0]?.url;if(url){$("cover").style.backgroundImage=`url('${url}')`;$("cover").textContent=""}}
async function search(q){
  if(!q.trim()){$("searchResults").innerHTML="";return}
  if(!localStorage.getItem("nf_token")){
    $("searchResults").innerHTML=`<div class="search-empty"><b>Connect Spotify first</b><span>NorthFace needs your Spotify connection to search your music universe.</span><button class="hero-ghost" onclick="login()">Connect Spotify ↗</button></div>`;return;
  }
  try{
    setStatus("Searching Spotify…");
    const d=await api(`/search?q=${encodeURIComponent(q)}&type=track&limit=10`);
    const items=d?.tracks?.items||[];
    $("searchResults").innerHTML=items.length?items.map(trackHTML).join(""):`<div class="search-empty"><b>No tracks found</b><span>Try another song, artist, or phrase.</span></div>`;
    bindTracks($("searchResults"));
    setStatus(`${items.length} tracks found`);
  }catch(e){
    console.error(e);
    $("searchResults").innerHTML=`<div class="search-empty"><b>Spotify search failed</b><span>${esc(e.message||"Please reconnect Spotify and try again.")}</span><button class="hero-ghost" onclick="login()">Reconnect ↗</button></div>`;
  }
}
function buildWave(){const n=matchMedia("(pointer:coarse)").matches?32:54;$("wave").innerHTML=Array.from({length:n},()=>`<i class="bar"></i>`).join("")}
function navTo(kind){document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.nav===kind));if(kind==="home")window.scrollTo({top:0,behavior:"smooth"});if(kind==="library"){if(!localStorage.getItem("nf_token"))login();else {$('library').classList.remove('hidden');$('library').scrollIntoView({behavior:"smooth"})}}if(kind==="search"){$("searchPanel").classList.remove("hidden");$("searchInput").focus();window.scrollTo({top:$('searchPanel').offsetTop-20,behavior:"smooth"})}if(kind==="lyrics")$("lyricsSection").scrollIntoView({behavior:"smooth"})}
function pulseUI(){$("heroVisual")?.classList.remove("beat");void $("heroVisual")?.offsetWidth;$('heroVisual')?.classList.add("beat")}
function touchFX(x,y){const root=$("touchFx");for(const type of ["touch-flash","touch-ring","touch-dot"]){const e=document.createElement("span");e.className=type;e.style.left=x+"px";e.style.top=y+"px";if(type==="touch-dot"){e.style.setProperty("--dx",`${(Math.random()-.5)*100}px`);e.style.setProperty("--dy",`${(Math.random()-.5)*100}px`)}root.appendChild(e);setTimeout(()=>e.remove(),850)}}

function initImmersion(){
 const glow=$("cursorGlow");
 document.addEventListener("pointermove",e=>{if(!matchMedia("(pointer:fine)").matches)return;if(glow){glow.style.left=e.clientX+"px";glow.style.top=e.clientY+"px"} const h=$("heroVisual"); if(h){const x=(e.clientX/innerWidth-.5)*12,y=(e.clientY/innerHeight-.5)*12;h.style.transform=`translate(${x}px,${y}px) translateY(-50%)`}});
 document.querySelectorAll(".experience-card,.lyrics-stage").forEach(addTilt);
 document.querySelectorAll("button,.track,.playlist,.experience-card").forEach(el=>el.addEventListener("pointerdown",e=>touchFX(e.clientX,e.clientY),{passive:true}));
}
function addTilt(el){if(matchMedia("(pointer:fine)").matches){el.addEventListener("pointermove",e=>{const r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;el.style.transform=`perspective(800px) rotateX(${y*-5}deg) rotateY(${x*5}deg) translateY(-3px)`});el.addEventListener("pointerleave",()=>el.style.transform="")}}
$("connectBtn").onclick=login;$("heroConnect").onclick=login;$("refreshBtn").onclick=loadLibrary;$("homeBtn").onclick=()=>navTo("home");$("demoBtn").onclick=()=>$("experience").scrollIntoView({behavior:"smooth"});$("backLibrary").onclick=()=>{$("playlistView").classList.add("hidden");$("playlistGrid").classList.remove("hidden")};$("searchOpen").onclick=()=>navTo("search");$("searchClose").onclick=()=>$("searchPanel").classList.add("hidden");let searchTimer;$("searchInput").oninput=e=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>search(e.target.value),220)};$("lyricsBtn").onclick=()=>$("lyricsSection").scrollIntoView({behavior:"smooth"});document.querySelectorAll(".bottom-nav button").forEach(b=>b.onclick=()=>navTo(b.dataset.nav));document.querySelectorAll(".mini-play").forEach(b=>b.onclick=()=>{touchFX(innerWidth/2,innerHeight/2);if(localStorage.getItem("nf_token"))setStatus(`${b.dataset.demo} atmosphere selected · pick a Spotify track`);else login()});$("play").onclick=async()=>{try{if(!player){await initPlayer(true)};if(player){await player.activateElement?.();await player.togglePlay()}}catch(e){console.error(e);setStatus("Tap a song first, then tap play again")}};$("prev").onclick=()=>player?.previousTrack();$("next").onclick=()=>player?.nextTrack();$("progress").oninput=e=>player?.getCurrentState().then(s=>s&&player.seek(s.duration*e.target.value/100));
initImmersion();
(async()=>{
  buildWave();
  try{
    await callback();
    if(localStorage.getItem("nf_token")){
      $("heroConnect").textContent="Spotify connected ✓";
      setStatus("Spotify connected · waking NorthFace player…");
      await loadLibrary();
    } else {
      setStatus("The summit is quiet. Connect Spotify to begin.");
    }
  }catch(e){console.error(e);setStatus(e.message||"Something went wrong");}
})();
