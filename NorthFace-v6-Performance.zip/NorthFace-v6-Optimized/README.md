# NorthFace v6 — Performance Edition

NorthFace Spotify PWA with a mobile performance pass. The design keeps the cinematic Everest/glass aesthetic while reducing expensive blur, background animation, DOM effects, and layout-triggering bar animations on touch devices.

The Android wrapper should point at the deployed NorthFace HTTPS site. This build does not include or require a Spotify Client Secret.
