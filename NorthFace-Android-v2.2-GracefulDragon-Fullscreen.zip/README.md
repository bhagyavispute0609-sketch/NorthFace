# NorthFace Android 2.2

Fullscreen Trusted Web Activity wrapper for the NorthFace website.

Website: https://graceful-dragon-6f9f89.netlify.app/

Package: com.northface.music
Version: 2.2 (5)

Build: GitHub Actions -> Build NorthFace APK -> Run workflow.
