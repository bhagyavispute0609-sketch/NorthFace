# NorthFace Android v1.1 Fixed

This build uses a lightweight Android launcher with an AndroidX Custom Tab instead of Trusted Web Activity. This avoids the launcher crash on some Android 16 devices while preserving the full NorthFace web app, Spotify login, search, playlists, and browser-based playback.

URL: https://capable-choux-e67f2b.netlify.app/

Build: `gradle assembleDebug`
