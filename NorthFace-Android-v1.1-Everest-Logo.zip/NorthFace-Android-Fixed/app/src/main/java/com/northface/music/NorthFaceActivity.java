package com.northface.music;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.browser.customtabs.CustomTabsIntent;

public class NorthFaceActivity extends Activity {
    private static final String NORTHFACE_URL = "https://capable-choux-e67f2b.netlify.app/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        openNorthFace();
    }

    private void openNorthFace() {
        Uri uri = Uri.parse(NORTHFACE_URL);
        try {
            CustomTabsIntent customTabs = new CustomTabsIntent.Builder()
                    .setShowTitle(false)
                    .build();
            customTabs.launchUrl(this, uri);
        } catch (Exception ignored) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (ActivityNotFoundException ignoredAgain) {
                // No browser available; leave the activity open rather than crashing.
            }
        }
    }
}
