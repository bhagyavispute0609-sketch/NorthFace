# NorthFace Android v2 — Fullscreen TWA

This build uses Trusted Web Activity so the site can render full-screen without the Custom Tab URL bar. Full-screen trust requires Digital Asset Links on the Netlify site.

Target URL: https://capable-choux-e67f2b.netlify.app/
Package: com.northface.music

The GitHub workflow prints the APK signing certificate SHA-256 fingerprint. That fingerprint must be placed in `/.well-known/assetlinks.json` on the Netlify site before the final fullscreen build.
